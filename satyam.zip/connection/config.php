<?php



$conn = mysqli_connect("localhost", "root", "123","studentdata");


if (!$conn) {
    die('connection Failed');
} else {

}

?>
<?php




