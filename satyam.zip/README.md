#ang
Question3)

Create a basic user login/registration system, i think this you have already implemented.
Use the same system if already done or else create a new system.


In this assignment, you need to create an advanced user management system.
The features of this system will be, user will have multiple roles "admin","user","guest"
Each user can who will login into the system, will have permissions to do certain things based on this his role.

Pages to Create
1) Create User Page
2) View User Page

There needs to be a standard left menu in all pages with options a) Create b) View All

Create User Page: In this page only the main admin user can invite another user to the system. He will add new users email id and role to invite him. The new user will get an email, where he will click on a link to accept this invitation. He will put in his firstname, lastname, date of birth (this will be a date picker) and password to create his account in this system.

View User Page: This page will simply show a list of all users, he we can edit users, delete users etc

admin role: users with this role can do anything in the system, all operations are allowed
user rolw: users with this role can only view and edit existing users. They cannot invite new users.
Guest: users with this role can only view users and not do anything else.


*important that the left menu should be a single html file. The left mene should not be repeated in different pages, rather just required.
