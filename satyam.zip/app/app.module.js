(function () {
'use strict';
angular.module('formApp',['ui.router', 'ngStorage','720kb.datepicker']);

})();